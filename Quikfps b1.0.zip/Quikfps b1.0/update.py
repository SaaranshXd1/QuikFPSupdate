import requests
import zipfile
import os
import sys
import time
import json
from io import BytesIO

# --- Config ---
UPDATE_JSON_URL = "https://raw.githubusercontent.com/SaaranshXd1/QuikFPSupdate/main/update.json"
LOCAL_VERSION_FILE = "version.json"
# --------------

def load_local_version():
    if not os.path.exists(LOCAL_VERSION_FILE):
        print("❌ version.json not found.")
        sys.exit(1)
    try:
        with open(LOCAL_VERSION_FILE, "r") as f:
            data = json.load(f)
            return str(data.get("version", "")).strip()
    except Exception as e:
        print(f"❌ Failed to read local version.json: {e}")
        sys.exit(1)

def fetch_update_info():
    try:
        print("🌐 Checking for updates...")
        response = requests.get(UPDATE_JSON_URL, timeout=5)
        response.raise_for_status()
        return response.json()
    except Exception as e:
        print(f"❌ Failed to fetch update.json: {e}")
        sys.exit(1)

def rename_old_files(current_version):
    print(f"🗃️ Backing up files to .old.{current_version}...")

    files_to_backup = [
        ("main.py", f"main.py.old.{current_version}"),
        ("quikfps.exe", f"quikfps.old.{current_version}.exe"),
        ("start.exe", f"start.old.{current_version}.exe"),
        ("reset.py", f"reset.old.{current_version}.py"),
        ("version.json", f"version.old.{current_version}.json"),
    ]

    for original, backup in files_to_backup:
        if os.path.exists(original):
            os.rename(original, backup)
            print(f"✔️ {original} → {backup}")

    if os.path.isdir("assets"):
        backup_assets = f"assets.old.{current_version}"
        os.rename("assets", backup_assets)
        print(f"✔️ assets/ → {backup_assets}")

def download_and_extract_zip(download_url):
    try:
        print("⬇️ Downloading update from:", download_url)
        response = requests.get(download_url, timeout=15)
        response.raise_for_status()

        with zipfile.ZipFile(BytesIO(response.content)) as zip_ref:
            zip_ref.extractall(".")
        print("✅ Update extracted successfully.")
    except Exception as e:
        print(f"❌ Failed to download or extract the update: {e}")
        sys.exit(1)

def restart_device():
    print("🔁 Restarting in 5 seconds...")
    time.sleep(5)
    if os.name == 'nt':
        os.system("shutdown /r /t 0")
    else:
        os.system("sudo reboot")

def check_and_update():
    local_version = load_local_version()
    update_info = fetch_update_info()

    online_version = str(update_info.get("version", "")).strip()
    download_url = str(update_info.get("download", "")).strip()

    print(f"🧩 Local version: {local_version}")
    print(f"🆕 Online version: {online_version}")

    if not online_version or not download_url:
        print("❌ update.json is missing 'version' or 'download'.")
        sys.exit(1)

    if online_version == local_version:
        print("✅ QuikFPS is up to date.")
    elif online_version > local_version:
        print(f"🚨 New update available! Updating to v{online_version}")
        rename_old_files(local_version)
        download_and_extract_zip(download_url)
        print("✅ Update complete.")
        restart_device()
    else:
        print("⚠️ Local version is newer than online version. Skipping update.")
        sys.exit(0)

# --- Entry Point ---
if __name__ == "__main__":
    check_and_update()
