import subprocess
import ctypes
import sys
import os
import json
import time

# Config file absolute path
CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")

# 🛡️ Run as admin
def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

if not is_admin():
    script = os.path.abspath(sys.argv[0])
    params = ' '.join([f'"{arg}"' for arg in sys.argv[1:]])
    ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, f'"{script}" {params}', None, 1)
    sys.exit()

class QuikFPSRevert:
    def __init__(self):
        print("🔄 QuikFPS Revert Tool - Restoring Default Windows Settings")
        print("=" * 60)

    def revert_telemetry(self):
        """Revert telemetry settings to default (enabled)"""
        try:
            print("🔄 Reverting Telemetry settings to default...")
            print("   ⏳ Accessing registry...")
            time.sleep(0.5)
            result = subprocess.run([
                'reg', 'add', r"HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection",
                '/v', 'AllowTelemetry', '/t', 'REG_DWORD', '/d', '3', '/f'
            ], capture_output=True, text=True)
            print("   ⏳ Setting AllowTelemetry=3...")
            time.sleep(0.3)
            print("✅ Telemetry reverted to default (Full telemetry)")
            return True
        except Exception as e:
            print(f"❌ Error reverting telemetry: {e}")
            return False

    def revert_gamebar(self):
        """Revert Game Bar settings to default (enabled)"""
        try:
            print("🔄 Reverting Game Bar settings to default...")
            cmds = [
                (r"HKCU\Software\Microsoft\GameBar", "AllowAutoGameMode", 1),
                (r"HKCU\Software\Microsoft\GameBar", "ShowStartupPanel", 1),
                (r"HKLM\SOFTWARE\Policies\Microsoft\Windows\GameDVR", "AllowGameDVR", 1),
                (r"HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR", "AppCaptureEnabled", 1),
            ]
            for reg_path, name, value in cmds:
                result = subprocess.run([
                    'reg', 'add', reg_path,
                    "/v", name, "/t", "REG_DWORD", "/d", str(value), "/f"
                ], capture_output=True, text=True)
                print(f"   Reverted {name} = {value}")
            print("✅ Game Bar reverted to default (enabled)")
            return True
        except Exception as e:
            print(f"❌ Error reverting Game Bar: {e}")
            return False

    def revert_hardware_acceleration(self):
        """Revert hardware acceleration to default (enabled)"""
        try:
            print("🔄 Reverting Hardware Acceleration for Edge...")
            result = subprocess.run([
                'reg', 'add', r"HKCU\Software\Microsoft\Edge\HardwareAccelerationModeEnabled",
                '/v', 'Enabled', '/t', 'REG_DWORD', '/d', '1', '/f'
            ], capture_output=True, text=True)
            print("✅ Hardware acceleration reverted to default (enabled)")
            return True
        except Exception as e:
            print(f"❌ Error reverting hardware acceleration: {e}")
            return False

    def revert_timer_resolution(self):
        """Reset timer resolution to default"""
        try:
            print("🔄 Reverting Timer Resolution to default...")
            # Reset to default resolution (15.6ms)
            ntdll = ctypes.WinDLL('ntdll')
            NtSetTimerResolution = ntdll.NtSetTimerResolution
            NtSetTimerResolution.argtypes = [ctypes.c_uint, ctypes.c_bool, ctypes.POINTER(ctypes.c_uint)]
            
            current_resolution = ctypes.c_uint()
            # Set to default (156250 = 15.625ms)
            NtSetTimerResolution(156250, False, ctypes.byref(current_resolution))
            print("✅ Timer resolution reverted to default")
            return True
        except Exception as e:
            print(f"❌ Error reverting timer resolution: {e}")
            return False

    def revert_cortana(self):
        """Revert Cortana to default (enabled)"""
        try:
            print("🔄 Reverting Cortana settings to default...")
            result = subprocess.run([
                'reg', 'add', r"HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search",
                '/v', 'AllowCortana', '/t', 'REG_DWORD', '/d', '1', '/f'
            ], capture_output=True, text=True)
            print("✅ Cortana reverted to default (enabled)")
            return True
        except Exception as e:
            print(f"❌ Error reverting Cortana: {e}")
            return False

    def revert_copilot(self):
        """Revert Copilot to default (enabled)"""
        try:
            print("🔄 Reverting Copilot settings to default...")
            result = subprocess.run([
                'reg', 'add', r"HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsCopilot",
                '/v', 'TurnOffWindowsCopilot', '/t', 'REG_DWORD', '/d', '0', '/f'
            ], capture_output=True, text=True)
            print("✅ Copilot reverted to default (enabled) - Restart required")
            return True
        except Exception as e:
            print(f"❌ Error reverting Copilot: {e}")
            return False

    def revert_gpu_scheduling(self):
        """Revert GPU Scheduling to default"""
        try:
            print("🔄 Reverting GPU Scheduling to default...")
            # Delete the registry key to restore default behavior
            result = subprocess.run([
                'reg', 'delete', r'HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers',
                '/v', 'HwSchMode', '/f'
            ], capture_output=True, text=True)
            print("✅ GPU Scheduling reverted to default - Restart required")
            return True
        except Exception as e:
            print(f"❌ Error reverting GPU Scheduling: {e}")
            return False

    def revert_game_priority(self):
        """Revert Game Priority settings to default"""
        try:
            print("🔄 Reverting Game Priority settings to default...")
            reg_path = r"HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games"
            
            # Delete custom values to restore defaults
            values_to_delete = ["GPU Priority", "Priority", "Scheduling Category", "SFIO Priority"]
            
            for value in values_to_delete:
                try:
                    subprocess.run([
                        'reg', 'delete', reg_path, '/v', value, '/f'
                    ], capture_output=True, text=True)
                    print(f"   Removed custom {value}")
                except:
                    pass  # Value might not exist
            
            print("✅ Game Priority reverted to default")
            return True
        except Exception as e:
            print(f"❌ Error reverting Game Priority: {e}")
            return False

    def revert_network_optimization(self):
        """Revert Network Performance settings to default"""
        try:
            print("🔄 Reverting Network Performance settings to default...")
            reg_path = r"HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters"
            
            values_to_delete = ["TcpAckFrequency", "TCPNoDelay", "TcpDelAckTicks", "TcpTimedWaitDelay"]
            
            for value in values_to_delete:
                try:
                    subprocess.run([
                        'reg', 'delete', reg_path, '/v', value, '/f'
                    ], capture_output=True, text=True)
                    print(f"   Removed custom {value}")
                except:
                    pass
            
            print("✅ Network Performance reverted to default - Restart required")
            return True
        except Exception as e:
            print(f"❌ Error reverting Network Performance: {e}")
            return False

    def revert_visual_effects(self):
        """Revert Visual Effects settings to default"""
        try:
            print("🔄 Reverting Visual Effects settings to default...")
            cmds = [
                (r"HKCU\Control Panel\Desktop", "MenuShowDelay", 400),  # Default value
                (r"HKCU\Control Panel\Desktop", "WaitToKillAppTimeout", 20000),  # Default value
                (r"HKCU\Control Panel\Desktop", "HungAppTimeout", 5000),  # Default value
                (r"HKCU\Control Panel\Desktop", "AutoEndTasks", 0)  # Default value
            ]
            
            for reg_path, name, value in cmds:
                result = subprocess.run([
                    'reg', 'add', reg_path, '/v', name, '/t', 'REG_DWORD', '/d', str(value), '/f'
                ], capture_output=True, text=True)
                print(f"   Reverted {name} = {value}")
            
            print("✅ Visual Effects reverted to default")
            return True
        except Exception as e:
            print(f"❌ Error reverting Visual Effects: {e}")
            return False

    def revert_system_responsiveness(self):
        """Revert System Responsiveness settings to default"""
        try:
            print("🔄 Reverting System Responsiveness settings to default...")
            reg_path = r"HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile"
            
            cmds = [
                (reg_path, "SystemResponsiveness", 20),  # Default value
                (reg_path, "NetworkThrottlingIndex", 10)  # Default value
            ]
            
            for path, name, value in cmds:
                result = subprocess.run([
                    'reg', 'add', path, '/v', name, '/t', 'REG_DWORD', '/d', str(value), '/f'
                ], capture_output=True, text=True)
                print(f"   Reverted {name} = {value}")
            
            print("✅ System Responsiveness reverted to default")
            return True
        except Exception as e:
            print(f"❌ Error reverting System Responsiveness: {e}")
            return False

    def revert_cpu_scheduling(self):
        """Revert CPU Scheduling to default"""
        try:
            print("🔄 Reverting CPU Scheduling to default...")
            reg_path = r"HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl"
            
            result = subprocess.run([
                'reg', 'add', reg_path, '/v', 'Win32PrioritySeparation', '/t', 'REG_DWORD', '/d', '2', '/f'
            ], capture_output=True, text=True)
            print("   Reverted Win32PrioritySeparation = 2 (default)")
            print("✅ CPU Scheduling reverted to default")
            return True
        except Exception as e:
            print(f"❌ Error reverting CPU Scheduling: {e}")
            return False

    def revert_memory_management(self):
        """Revert Memory Management settings to default"""
        try:
            print("🔄 Reverting Memory Management settings to default...")
            reg_path = r"HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management"
            
            cmds = [
                (reg_path, "LargeSystemCache", 1),  # Default for servers, 0 for workstations
                (reg_path, "DisablePagingExecutive", 0),  # Default value
                (reg_path, "ClearPageFileAtShutdown", 0)  # Default value
            ]
            
            for path, name, value in cmds:
                result = subprocess.run([
                    'reg', 'add', path, '/v', name, '/t', 'REG_DWORD', '/d', str(value), '/f'
                ], capture_output=True, text=True)
                print(f"   Reverted {name} = {value}")
            
            print("✅ Memory Management reverted to default - Restart required")
            return True
        except Exception as e:
            print(f"❌ Error reverting Memory Management: {e}")
            return False

    def revert_windows_search(self):
        """Revert Windows Search to default (enabled)"""
        try:
            print("🔄 Reverting Windows Search to default...")
            
            # Set service to automatic
            result = subprocess.run([
                'reg', 'add', r"HKLM\SYSTEM\CurrentControlSet\Services\WSearch",
                '/v', 'Start', '/t', 'REG_DWORD', '/d', '2', '/f'
            ], capture_output=True, text=True)
            print("   Set WSearch service to automatic")
            
            # Start the service
            try:
                subprocess.run(['sc', 'start', 'wsearch'], capture_output=True, text=True)
                print("   Windows Search service started")
            except:
                print("   Note: Service will start on next boot")
            
            print("✅ Windows Search reverted to default (enabled)")
            return True
        except Exception as e:
            print(f"❌ Error reverting Windows Search: {e}")
            return False

    def revert_prefetch_settings(self):
        """Revert Prefetch settings to default"""
        try:
            print("🔄 Reverting Prefetch settings to default...")
            reg_path = r"HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters"
            
            cmds = [
                (reg_path, "EnablePrefetcher", 3),  # Default: enabled for both apps and boot
                (reg_path, "EnableSuperfetch", 1)   # Default: enabled
            ]
            
            for path, name, value in cmds:
                result = subprocess.run([
                    'reg', 'add', path, '/v', name, '/t', 'REG_DWORD', '/d', str(value), '/f'
                ], capture_output=True, text=True)
                print(f"   Reverted {name} = {value}")
            
            print("✅ Prefetch settings reverted to default")
            return True
        except Exception as e:
            print(f"❌ Error reverting Prefetch settings: {e}")
            return False

    def revert_gpu_timeout(self):
        """Revert GPU Timeout to default"""
        try:
            print("🔄 Reverting GPU Timeout to default...")
            reg_path = r"HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers"
            
            # Delete custom TdrDelay to restore default (2 seconds)
            result = subprocess.run([
                'reg', 'delete', reg_path, '/v', 'TdrDelay', '/f'
            ], capture_output=True, text=True)
            print("   Removed custom TdrDelay (restored to default 2 seconds)")
            print("✅ GPU Timeout reverted to default")
            return True
        except Exception as e:
            print(f"❌ Error reverting GPU Timeout: {e}")
            return False

    def clear_config_file(self):
        """Clear the config file"""
        try:
            print("🔄 Clearing config file...")
            if os.path.exists(CONFIG_PATH):
                with open(CONFIG_PATH, "w", encoding='utf-8') as f:
                    json.dump({}, f, indent=2)
                print("✅ Config file cleared")
            else:
                print("ℹ️ Config file doesn't exist")
            return True
        except Exception as e:
            print(f"❌ Error clearing config file: {e}")
            return False

    def run_full_revert(self):
        """Run all revert operations"""
        print("🚀 Starting full revert process...\n")
        
        operations = [
            ("Telemetry", self.revert_telemetry),
            ("Game Bar", self.revert_gamebar),
            ("Hardware Acceleration", self.revert_hardware_acceleration),
            ("Timer Resolution", self.revert_timer_resolution),
            ("Cortana", self.revert_cortana),
            ("Copilot", self.revert_copilot),
            ("GPU Scheduling", self.revert_gpu_scheduling),
            ("Game Priority", self.revert_game_priority),
            ("Network Optimization", self.revert_network_optimization),
            ("Visual Effects", self.revert_visual_effects),
            ("System Responsiveness", self.revert_system_responsiveness),
            ("CPU Scheduling", self.revert_cpu_scheduling),
            ("Memory Management", self.revert_memory_management),
            ("Windows Search", self.revert_windows_search),
            ("Prefetch Settings", self.revert_prefetch_settings),
            ("GPU Timeout", self.revert_gpu_timeout),
            ("Config File", self.clear_config_file)
        ]
        
        success_count = 0
        total_count = len(operations)
        
        for name, operation in operations:
            try:
                print(f"🔧 Processing: {name}")
                time.sleep(0.2)
                if operation():
                    success_count += 1
                    print(f"   ✅ {name} completed")
                else:
                    print(f"   ❌ {name} failed")
                print("-" * 40)
                time.sleep(0.3)
            except Exception as e:
                print(f"❌ Unexpected error in {name}: {e}")
                print("-" * 40)
        
        print("=" * 60)
        print(f"🎯 Revert Summary: {success_count}/{total_count} operations completed successfully")
        
        if success_count == total_count:
            print("✅ All QuikFPS tweaks have been successfully reverted!")
        else:
            print("⚠️ Some operations failed. Please check the output above.")
        
        print("\n🔄 RESTART REQUIRED: Please restart your computer to apply all changes.")
        print("=" * 60)

if __name__ == "__main__":
    try:
        reverter = QuikFPSRevert()
        reverter.run_full_revert()
        
        input("\nPress Enter to exit...")
        
    except KeyboardInterrupt:
        print("\n\n❌ Operation cancelled by user.")
    except Exception as e:
        print(f"\n❌ Unexpected error: {e}")
        input("Press Enter to exit...")