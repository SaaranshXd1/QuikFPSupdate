#!/usr/bin/env python3
"""
QuikFPS terminal reset
=============================
This script completely reverts ALL changes made by QuikFPS.
- Resets all registry modifications to Windows defaults
- Deletes the config.json file
- Resets timer resolution to system default
- Provides detailed feedback on each operation

Run this script as Administrator!
"""

import subprocess
import ctypes
import sys
import os
import json
import winreg
from pathlib import Path

def is_admin():
    """Check if running as administrator"""
    try:
        return ctypes.windll.shell32.IsUserAnAdmin()
    except:
        return False

def run_as_admin():
    """Re-run this script as administrator"""
    if not is_admin():
        print("🛡️ This script needs Administrator privileges!")
        print("Restarting as Administrator...")
        script = os.path.abspath(sys.argv[0])
        params = ' '.join([f'"{arg}"' for arg in sys.argv[1:]])
        ctypes.windll.shell32.ShellExecuteW(None, "runas", sys.executable, f'"{script}" {params}', None, 1)
        sys.exit()

def set_registry_value(hive, key_path, value_name, value_data, value_type, description):
    """Set a registry value directly"""
    try:
        with winreg.OpenKey(hive, key_path, 0, winreg.KEY_SET_VALUE) as key:
            winreg.SetValueEx(key, value_name, 0, value_type, value_data)
        print(f"✅ {description}")
        return True
    except FileNotFoundError:
        # Key doesn't exist, create it
        try:
            with winreg.CreateKey(hive, key_path) as key:
                winreg.SetValueEx(key, value_name, 0, value_type, value_data)
            print(f"✅ {description} (created key)")
            return True
        except Exception as e:
            print(f"❌ {description} - Error creating key: {str(e)}")
            return False
    except Exception as e:
        print(f"❌ {description} - Error: {str(e)}")
        return False

def delete_registry_key(hive, key_path, description):
    """Delete a registry key directly"""
    try:
        winreg.DeleteKey(hive, key_path)
        print(f"✅ {description}")
        return True
    except FileNotFoundError:
        print(f"ℹ️  {description} (key didn't exist - that's OK)")
        return True
    except Exception as e:
        print(f"❌ {description} - Error: {str(e)}")
        return False

def delete_registry_value(hive, key_path, value_name, description):
    """Delete a registry value directly"""
    try:
        with winreg.OpenKey(hive, key_path, 0, winreg.KEY_SET_VALUE) as key:
            winreg.DeleteValue(key, value_name)
        print(f"✅ {description}")
        return True
    except FileNotFoundError:
        print(f"ℹ️  {description} (key/value didn't exist - that's OK)")
        return True
    except Exception as e:
        print(f"❌ {description} - Error: {str(e)}")
        return False

def reset_telemetry():
    """Reset telemetry settings to Windows default"""
    print("\n📊 Resetting Telemetry Settings...")
    
    # Reset to Windows default (Basic = 1, Full = 3)
    return set_registry_value(
        winreg.HKEY_LOCAL_MACHINE,
        r"SOFTWARE\Policies\Microsoft\Windows\DataCollection",
        "AllowTelemetry",
        3,
        winreg.REG_DWORD,
        "Telemetry re-enabled (set to Full)"
    )

def reset_gamebar():
    """Reset Game Bar settings to Windows defaults"""
    print("\n🎮 Resetting Game Bar Settings...")
    
    success = True
    
    # Re-enable Game Bar Auto Game Mode
    if not set_registry_value(
        winreg.HKEY_CURRENT_USER,
        r"Software\Microsoft\GameBar",
        "AllowAutoGameMode",
        1,
        winreg.REG_DWORD,
        "Game Bar Auto Game Mode re-enabled"
    ):
        success = False
    
    # Re-enable Game Bar Startup Panel
    if not set_registry_value(
        winreg.HKEY_CURRENT_USER,
        r"Software\Microsoft\GameBar",
        "ShowStartupPanel",
        1,
        winreg.REG_DWORD,
        "Game Bar Startup Panel re-enabled"
    ):
        success = False
    
    # Remove Game DVR policies (back to default)
    if not delete_registry_key(
        winreg.HKEY_LOCAL_MACHINE,
        r"SOFTWARE\Policies\Microsoft\Windows\GameDVR",
        "Game DVR policies removed (back to default)"
    ):
        success = False
    
    return success

def reset_hardware_acceleration():
    """Reset hardware acceleration to default"""
    print("\n⚡ Resetting Hardware Acceleration...")
    
    return delete_registry_value(
        winreg.HKEY_CURRENT_USER,
        r"Software\Microsoft\Edge",
        "HardwareAccelerationModeEnabled",
        "Edge Hardware Acceleration reset to default"
    )

def reset_copilot():
    """Reset Copilot settings"""
    print("\n🤖 Resetting Copilot Settings...")
    
    return delete_registry_key(
        winreg.HKEY_LOCAL_MACHINE,
        r"SOFTWARE\Policies\Microsoft\Windows\WindowsCopilot",
        "Copilot policies removed (back to default)"
    )

def reset_cortana():
    """Reset Cortana settings"""
    print("\n🔍 Resetting Cortana Settings...")
    
    return delete_registry_key(
        winreg.HKEY_LOCAL_MACHINE,
        r"SOFTWARE\Policies\Microsoft\Windows\Windows Search",
        "Cortana search policies removed (back to default)"
    )

def reset_gpu_scheduling():
    """Reset GPU scheduling to Windows default"""
    print("\n🖥️  Resetting GPU Scheduling...")
    
    # Set to 1 (default) instead of 2 (hardware-accelerated)
    return set_registry_value(
        winreg.HKEY_LOCAL_MACHINE,
        r"SYSTEM\CurrentControlSet\Control\GraphicsDrivers",
        "HwSchMode",
        1,
        winreg.REG_DWORD,
        "GPU Scheduling reset to default"
    )

def reset_timer_resolution():
    """Reset timer resolution to system default"""
    print("\n⏱️  Resetting Timer Resolution...")
    
    try:
        # Reset to default resolution (usually 15.6ms)
        ntdll = ctypes.WinDLL('ntdll')
        NtSetTimerResolution = ntdll.NtSetTimerResolution
        NtSetTimerResolution.argtypes = [ctypes.c_uint, ctypes.c_bool, ctypes.POINTER(ctypes.c_uint)]
        
        current_resolution = ctypes.c_uint()
        # Set to False to use system default
        NtSetTimerResolution(156250, False, ctypes.byref(current_resolution))  # ~15.6ms default
        print("✅ Timer resolution reset to system default")
        return True
    except Exception as e:
        print(f"❌ Error resetting timer resolution: {str(e)}")
        return False

def delete_config_file():
    """Delete the QuikFPS config file"""
    print("\n📄 Removing Config Files...")
    
    config_files = ["config.json", "config.txt"]  # Check both possible names
    deleted_any = False
    
    for config_file in config_files:
        if os.path.exists(config_file):
            try:
                os.remove(config_file)
                print(f"✅ Deleted {config_file}")
                deleted_any = True
            except Exception as e:
                print(f"❌ Failed to delete {config_file}: {str(e)}")
        else:
            print(f"ℹ️  {config_file} not found (already clean)")
    
    return True  # Don't fail the whole script if config deletion fails

def main():
    """Main reset function"""
    print("=" * 50)
    print("🔄 QuikFPS Complete Reset Script")
    print("=" * 50)
    print("This will undo ALL changes made by QuikFPS")
    print("and restore Windows to default settings.")
    print()
    
    # Check admin privileges
    run_as_admin()
    
    # Confirm with user
    response = input("Are you sure you want to reset everything? (y/N): ").lower().strip()
    if response not in ['y', 'yes']:
        print("❌ Reset cancelled by user.")
        return
    
    print("\n🚀 Starting complete reset...")
    
    # Track success of each operation
    operations = [
        ("Telemetry", reset_telemetry),
        ("Game Bar", reset_gamebar),
        ("Hardware Acceleration", reset_hardware_acceleration),
        ("Copilot", reset_copilot),
        ("Cortana", reset_cortana),
        ("GPU Scheduling", reset_gpu_scheduling),
        ("Timer Resolution", reset_timer_resolution),
        ("Config Files", delete_config_file),
    ]
    
    successful = 0
    total = len(operations)
    
    for name, operation in operations:
        try:
            if operation():
                successful += 1
        except Exception as e:
            print(f"❌ Unexpected error in {name}: {str(e)}")
    
    # Final summary
    print("\n" + "=" * 50)
    print("🏁 Reset Complete!")
    print("=" * 50)
    print(f"✅ Successful operations: {successful}/{total}")
    
    if successful == total:
        print("🎉 All QuikFPS changes have been successfully reverted!")
        print("💡 Your system is now back to Windows defaults.")
    else:
        print(f"⚠️  {total - successful} operations had issues (check output above)")
        print("💡 Most settings should still be reset correctly.")
    
    print("\n🔄 Restart your PC to ensure all changes take effect.")
    
    # Wait for user before closing
    input("\nPress Enter to exit...")

if __name__ == "__main__":
    main()