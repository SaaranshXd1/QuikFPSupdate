QuikFPS Alpha - Closed Build License Agreement
Copyright (c) 2025 Saaransh_Xd. All rights reserved.

This version of QuikFPS ("the Software") is an early-access, private build intended only for authorized testers or internal use. By using or installing this Software, you agree to the following terms:

1. LIMITED LICENSE
   - You are granted temporary, non-transferable access to test and use this Software.
   - You may NOT share, upload, distribute, leak, or expose any part of this Software or its contents.
   - Usage is strictly limited to those invited by Saaransh_Xd.

2. CONFIDENTIALITY
   - All features, design, performance data, and related feedback are confidential.
   - You may not disclose, share screenshots, videos, or describe the software publicly unless given written permission.

3. OWNERSHIP
   - This is a proprietary and unpublished work owned entirely by Saaransh_Xd.
   - No rights are transferred through this agreement.

4. REVERSE ENGINEERING
   - You may not decompile, disassemble, modify, or reverse engineer any part of the Software.

5. WARRANTY DISCLAIMER
   - This is an ALPHA build. It may contain bugs, incomplete features, or cause system instability.
   - Use at your own risk. No warranties or guarantees are provided.

6. TERMINATION
   - This license may be revoked at any time, without notice, for any reason.
   - Upon termination, you must delete all copies of the Software immediately.

7. SECURITY NOTICE
   - If you did not receive this Software directly from Saaransh_Xd or an authorized link, it may have been tampered with.
   - Do not trust third-party uploads or "leaked" versions.

